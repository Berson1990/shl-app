@extends('admintempate.admintempate')

@section('page-style-level')
    <style>
        .dir {
            direction: rtl;
        }
    </style>
@endsection

@section('content')
    <div id="services">
        <div class="row">
            <data-tables :data="servicesData" :show-action-bar="false" :custom-filters="customFilters"
                         :actions-def="actionsDef">
                <el-row slot="custom-tool-bar" style="margin-bottom: 10px ; text-align: center">
                    <el-col :span="5">
                        <el-input v-model="customFilters[0].vals">
                        </el-input>
                    </el-col>

                    <el-col :span="19">
                        <el-button type="success" data-toggle="modal" data-target="#myModal">اضافه خدمة جديدة
                        </el-button>
                    </el-col>
                </el-row>
                <el-table-column label="تعديل">
                    <template slot-scope="scope">
                        <el-button
                                class="el-icon-edit"
                                size="medium"
                                type="warning"
                                @click="handleEdit(scope.$index, scope.row)">
                            &nbsp;&nbsp;
                            تعديل


                        </el-button>
                    </template>
                </el-table-column>

                <el-table-column
                        prop="services_name_ar"
                        label="الخدمة"
                >
                </el-table-column>

                <el-table-column label="الخدمات الفرعية">
                    <template slot-scope="scope">

                        <el-button
                                class="fa fa-arrows-alt"
                                size="medium"
                                type="primary"
                                @click="subSerivcesDisplay(scope.$index, scope.row)">
                            &nbsp;&nbsp;
                            الخدمات الفرعية
                        </el-button>
                    </template>
                </el-table-column>

                <el-table-column label="ايقاف">
                    <template slot-scope="scope">

                        <el-button
                                class="fa fa-stop-circle"
                                size="medium"
                                type="danger"
                                @click="handleDelete(scope.$index, scope.row)">&nbsp; &nbsp;ايقاف

                        </el-button>
                    </template>
                </el-table-column>

            </data-tables>
        </div>
    </div>


@endsection
@section('page-script-level')
    <script src="{{asset('AppAdmin/services.js')}}"></script>
@endsection