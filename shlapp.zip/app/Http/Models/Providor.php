<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Providor extends Model
{
    protected $table = 'providor';
    protected $primaryKey = 'provider_id';
    protected $fillable = [
        'user_id',
        'license_number',
        'vehicle_number',
        'services_id',
        'sub_services_id',
        'personal_pic',
        'license_pic',
        'lat',
        'long',
        'active',
    ];

    public function Users(){

        return $this->belongsTo('App\Http\Models\Users','user_id');
    }

}