<?php

namespace App\Http\Models;

use \Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $fillable = ['phone',
        'user_name',
        'email',
        'profile_pic',
        'activate',
        'v_code',
        'type',
        'token_id',
        'city_id',
        'zone_id',
        'lang_id',

    ];

    public function Orders()
    {
        return $this->hasMany('App\Http\Models\Order', 'user_id');
    }

    public function Providor()
    {
        return $this->hasMany('App\Http\Models\Providor', 'user_id');
    }
}