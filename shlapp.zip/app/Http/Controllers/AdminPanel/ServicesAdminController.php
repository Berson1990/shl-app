<?php

namespace App\Http\Controllers\AdminPanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Models\Services;
use App\Http\Models\SubServices;

class ServicesAdminController extends Controller
{
    //
    public function __construct()
    {
        $this->serivces = new Services();
        $this->sub_services = new SubServices();

    }

    public function index()
    {
        return view('services.services');
    }

    public function GetServices()
    {
        return $output = $this->serivces
            ->with('SupSerivcesData')
            ->get();

    }
}
