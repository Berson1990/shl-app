<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Users;
use App\Http\Models\Providor;

class UsersController extends Controller
{
    //

    public function __construct()
    {
        $this->users = new Users();
        $this->provider = new Providor();
    }

    public function Login()
    {
        $input = Request()->all();

        $check = $this->users->where('phone', $input['phone'])->get();
        if (count($check) > 0) {
            return Response()->json($check['0']);
        } else {
            $input['v_code'] = $this->GenerateVCode();
            $this->SendSMSWithVcode($input['phone'], $input['v_code']);
            $output = $this->users->create($input);
            return Response()->json($output);
        }

    }


    public function Activate()
    {
        $input = Request()->all();
        $check = $this->users->where('phone', $input['phone'])->get();
        if (count($check) < 0) {
            return ['state' => 'error'];
        } else {
            $this->users->where('phone', $input['phone'])->update(
                [
                    'activate' => 1,
                    'v_code' => $input['v_code']

                ]
            );
            $check = $this->users->where('phone', $input['phone'])->get();
            return Response()->json($check['0']);

        }

    }


    public function UpdateUserAccount($id)
    {

        $input = Request()->all();
        /* personal_pic*/
        $personal_pic = $input["profile_pic"];
        $image_name = "pic-" . time() . ".png";
        $path = public_path() . "/personal_pic/" . $image_name;
        $input["personal_pic"] = "/personal_pic/" . $image_name;
        $voc = substr($personal_pic, strpos($image_name, ",") + 1);//take string after ,
        $voicedata = base64_decode($voc);
        $success = file_put_contents($path, $voicedata);

        $this->users->find($id)->update($input);

        return $this->users->where('user_id', $id)->get();

    }

    protected function SendSMSWithVcode($phone, $vcode)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "http://api.unifonic.com/rest/Messages/Send");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
//        curl_setopt($ch, CURLOPT_POSTFIELDS, "AppSid=SHL-APP-AD&Recipient=' . $phone . '&Body=' . $vcode . '");
        curl_setopt($ch, CURLOPT_POSTFIELDS, "AppSid=dEYXJ5rv9DIGllCkJZ4Ngmx7u1Zzsh&Recipient=' . $phone . '&Body=' . $vcode . '");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Content-Type: application/x-www-form-urlencoded"
        ));

        $response = curl_exec($ch);
        curl_close($ch);
//        var_dump($response);
    }

    protected function GenerateVCode()
    {
        return $six_digit_random_number = mt_rand(100000, 999999);
    }


    public function CreateProvidor()
    {
        $input = Request()->all();

        $check = $this->users->where('phone', $input['phone'])->get();
        if (count($check) > 0) {


            return Response()->json($check['0']);


        } else {
            $users = $this->users->create([
                "user_name" => $input['user_name'],
                "phone" => $input['phone']
            ]);
            $user_id = $users->user_id;

            /* personal_pic*/
            $personal_pic = $input["personal_pic"];
            $image_name = "pic-" . time() . ".png";
            $path = public_path() . "/personal_pic/" . $image_name;
            $input["personal_pic"] = "/personal_pic/" . $image_name;
            $voc = substr($personal_pic, strpos($image_name, ",") + 1);//take string after ,
            $voicedata = base64_decode($voc);
            $success = file_put_contents($path, $voicedata);

            /*license_pic*/
            $license_pic = $input["license_pic"];
            $license_pic_name = "pic-" . time() . ".png";
            $path = public_path() . "/license_pic/" . $license_pic_name;
            $input["license_pic"] = "/license_pic/" . $license_pic_name;
            $voc = substr($license_pic, strpos($license_pic_name, ",") + 1);//take string after ,
            $voicedata = base64_decode($voc);
            $success = file_put_contents($path, $voicedata);
            $input['user_id'] = $user_id;
            $output = $this->provider->create($input);
            $output = $this->users->with('Providor')
                ->where($this->users->getTable() . '.user_id', $user_id)
                ->get();
            return Response()->json($output);
        }

    }

    public function UpdateProviderLocations($id)
    {
        $input = Request()->all();
        $updateLocation = $this->provider->find($id)->update([
            "long" => $input['long'],
            "lat" => $input['lat']
        ]);

        $output = $this->provider->select('long', 'lat', 'provider_id')->where('provider_id', $id)->get();
        return Response()->json($output);


    }

    public function ChangActive($id)
    {

        $input = Request()->all();
        $updateLocation = $this->provider->find($id)->update([
            'active' => $input['active']
        ]);

        $output = $this->provider->select('active', 'provider_id')->where('provider_id', $id)->get();
        return Response()->json($output);


    }

    public function UpdateUserToken($id)
    {
        $input = Request()->all();
        $this->users->find($id)->update(['token_id' => $input['token_id']]);
        $output = $this->users->select('token_id')->where('user_id', $id)->get();
        return Response()->json($output['0']);

    }

    public function UpdateProviderToken($id)
    {
        $input = Request()->all();
        global $user_id;
        $getUserID = $this->provider
            ->select('user_id')
            ->where('provider_id', $id)->get();
        foreach ($getUserID as $userID) {
            $user_id = $userID->user_id;

            $this->users->find($user_id)->update(['token_id' => $input['token_id']]);

        }
        $output = $this->users->select('token_id')->where('user_id', $user_id)->get();

        return Response()->json($output['0']);

    }


}
